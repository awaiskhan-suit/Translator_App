import 'package:flutter/material.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController msg = TextEditingController();

  String translateMsg = '';

  final OnDeviceTranslator translator = OnDeviceTranslator(
    sourceLanguage: TranslateLanguage.english,
    targetLanguage: TranslateLanguage.urdu,
  );

  final OnDeviceTranslatorModelManager modelManager =
  OnDeviceTranslatorModelManager();

  @override
  void initState() {
    super.initState();
    downloadModels();
  }

  // Download English and Urdu translation models
  Future<void> downloadModels() async {
    try {
      bool isEnglish = await modelManager.isModelDownloaded(
        TranslateLanguage.english.bcpCode,
      );

      bool isUrdu = await modelManager.isModelDownloaded(
        TranslateLanguage.urdu.bcpCode,
      );

      if (!isEnglish) {
        await modelManager.downloadModel(
          TranslateLanguage.english.bcpCode,
        );
      }

      if (!isUrdu) {
        await modelManager.downloadModel(
          TranslateLanguage.urdu.bcpCode,
        );
      }
    } catch (e) {
      debugPrint("Model download error: $e");
    }
  }

  // Translate text
  Future<void> translate() async {
    if (msg.text.trim().isEmpty) {
      return;
    }

    try {
      String result = await translator.translateText(msg.text);

      setState(() {
        translateMsg = result;
      });
    } catch (e) {
      debugPrint("Translation error: $e");
    }
  }

  @override
  void dispose() {
    msg.dispose();
    translator.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Language Translator"),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),

      body: ListView(
        padding: const EdgeInsets.all(15),

        children: [
          TextField(
            controller: msg,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: "Your Message",
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 20),

          ElevatedButton(
            onPressed: translate,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: const Text("Translate"),
          ),

          const SizedBox(height: 20),

          ListTile(
            title: Text(
              translateMsg,
              style: const TextStyle(
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }
}